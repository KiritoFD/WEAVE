"""Microbenchmark for every NEW training arm: real VRAM and sec/update.

The 24h plan requires this before starting the queue (section 7.2): the decoder
batch of 8 says nothing about training batch, and A/B/C have very different
memory profiles (B keeps a K-step R1 graph). This measures, per arm:

  peak_vram_mb, sec_per_update  at several microbatch sizes

and prints the largest microbatch that fits, plus the gradient-accumulation
factor needed to keep each arm's registered effective batch.

No experiment result is produced here.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
import torch.nn as nn

REPO = Path(__file__).resolve().parents[2]
Q2A = REPO / "runs/v6/Q2a_embed_style/Q2a_embed_style.pt"
B4 = REPO / "runs/v6/P1_B4_distill50/P1_B4_distill50.pt"


def _load(device):
    from src.infer import canonicalizer, load_c3unet, load_critic
    base, _ = load_c3unet(Q2A, device)
    canon = canonicalizer(device)
    critic = load_critic(device)
    return base, canon, critic


def bench_control(batch, device, spec_name="hier_palette"):
    """A3/A4 shape: frozen generator, train the control policy head."""
    from exp.v8.controls import ControlSpec, Controls, wrap
    base, canon, critic = _load(device)
    spec = ControlSpec(local_rank=2 if "local" in spec_name else 0)
    gen = wrap(base, spec, device)
    head = torch.nn.Sequential(
        torch.nn.Linear(spec.dim, 128), torch.nn.SiLU(),
        torch.nn.Linear(128, spec.dim)).to(device)
    # Non-zero final layer: a zero policy would make the loss independent of the
    # head's parameters and backward would (correctly) fail.
    nn.init.normal_(head[-1].weight, std=0.01)
    nn.init.zeros_(head[-1].bias)
    opt = torch.optim.AdamW(list(head.parameters()), lr=2e-4)
    torch.cuda.reset_peak_memory_stats()
    z = torch.randn(batch, 4, 64, 64, device=device)
    tid = torch.randint(0, 5, (batch,), device=device)
    t0 = time.time()
    with torch.no_grad():
        c = canon(z, mode="c1_gentle", augment=False)
    u = head(torch.randn(batch, spec.dim, device=device))
    out = gen(c, 0.0, c, tid, controls=Controls.from_tensor(u, spec))
    margin = _margin(critic, out, tid)
    loss = torch.nn.functional.softplus(-margin).mean()
    opt.zero_grad(); loss.backward(); opt.step()
    torch.cuda.synchronize()
    dt = time.time() - t0
    return {"arm": "A3/A4", "microbatch": batch, "sec_per_update": round(dt, 4),
            "peak_vram_mb": round(torch.cuda.max_memory_allocated() / 2**20, 1)}


def bench_spd(batch, device, steps_k=2, rank=2):
    """L2/L3 shape: K-step R1 unroll with a graph through every step."""
    from exp.v8.guidance import LatentSPDEditor, SPDHead, UnrollConfig
    base, canon, critic = _load(device)
    head = SPDHead(rank=rank).to(device)
    cfg = UnrollConfig(steps=steps_k, step_rms=0.08, rho=0.25)
    ed = LatentSPDEditor(critic, head, cfg).to(device)
    opt = torch.optim.AdamW(head.parameters(), lr=2e-4)
    torch.cuda.reset_peak_memory_stats()
    z = torch.randn(batch, 4, 64, 64, device=device)
    tid = torch.randint(0, 5, (batch,), device=device)
    t0 = time.time()
    with torch.no_grad():
        c = canon(z, mode="c1_gentle", augment=False)
        z0 = base(c, 0.0, c, tid).detach()
    res = ed(z0, c, tid)
    margin = _margin(critic, res["final"], tid)
    loss = torch.nn.functional.softplus(-margin).mean() + res["final"].square().mean() * 0.0
    opt.zero_grad(); loss.backward(); opt.step()
    torch.cuda.synchronize()
    dt = time.time() - t0
    return {"arm": f"L(rank={rank},K={steps_k})", "microbatch": batch,
            "sec_per_update": round(dt, 4),
            "peak_vram_mb": round(torch.cuda.max_memory_allocated() / 2**20, 1)}


def bench_critic(batch, device):
    """C3 shape: fine-tune R1 on real latents."""
    from exp.v8.energy import robustness_finetune_step
    _, _, critic = _load(device)
    for p in critic.parameters():
        p.requires_grad_(True)
    opt = torch.optim.AdamW(critic.parameters(), lr=5e-5)
    torch.cuda.reset_peak_memory_stats()
    z = torch.randn(batch, 4, 64, 64, device=device)
    tid = torch.randint(0, 5, (batch,), device=device)
    t0 = time.time()
    robustness_finetune_step(critic, z, tid, opt)
    torch.cuda.synchronize()
    dt = time.time() - t0
    return {"arm": "C3", "microbatch": batch, "sec_per_update": round(dt, 4),
            "peak_vram_mb": round(torch.cuda.max_memory_allocated() / 2**20, 1)}


def _margin(critic, z, tid):
    import torch.nn.functional as F
    logits = critic(z.float()).float()
    mask = F.one_hot(tid.long(), 5).bool()
    others = logits.masked_fill(mask, torch.finfo(logits.dtype).min)
    return logits.gather(1, tid[:, None]).squeeze(1) - torch.logsumexp(others, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--batches", type=int, nargs="+", default=[4, 8, 16])
    a = ap.parse_args()
    results = []
    for b in a.batches:
        for fn, kw in ((bench_control, {}),
                       (bench_spd, {"steps_k": 2, "rank": 2}),
                       (bench_spd, {"steps_k": 2, "rank": 0}),
                       (bench_critic, {})):
            try:
                torch.cuda.empty_cache()
                r = fn(b, a.device, **kw)
                results.append(r)
                print("BENCH", r, flush=True)
            except torch.OutOfMemoryError as e:
                results.append({"arm": fn.__name__, "microbatch": b,
                                "error": "OOM", "detail": str(e)[:120]})
                print(f"BENCH OOM microbatch={b} {fn.__name__}", flush=True)
                torch.cuda.empty_cache()
    out = REPO / "runs/v8"; out.mkdir(parents=True, exist_ok=True)
    (out / "train_bench.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print("wrote runs/v8/train_bench.json", flush=True)


if __name__ == "__main__":
    main()
