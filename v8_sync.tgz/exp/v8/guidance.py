"""B: Learned Gradient Geometry — content-sensitive positive-definite updates.

Why positive-definite and not a free residual
---------------------------------------------
With g = grad_z F_t(z) and delta = eta * P g, if P is positive definite then to
first order

    F_t(z + eta P g) - F_t(z) = eta g^T P g + O(eta^2) >= eta * eps * ||g||^2

so the update still ascends the style objective. A free residual network has no
such guarantee, which is exactly how the earlier N1/N2 correctors drifted into
content collapse. Content safety is a SEPARATE issue and is enforced on the
actual output, not assumed from definiteness.

Two parameterisations, both trained against the FINAL generated result:
  B-z : P acts on the raw latent gradient, predicted per position
  B-u : P acts in the generator's control coordinates (see exp.v8.controls)
No teacher endpoint is ever fitted.
"""
from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


def target_margin(critic, z: torch.Tensor, tid: torch.Tensor) -> torch.Tensor:
    """m_t(z) = logit_t - logsumexp_{j != t} logit_j, per sample."""
    logits = critic(z.float()).float()
    mask = F.one_hot(tid.long(), 5).bool()
    others = logits.masked_fill(mask, torch.finfo(logits.dtype).min)
    return logits.gather(1, tid[:, None]).squeeze(1) - torch.logsumexp(others, 1)


def rms(x: torch.Tensor) -> torch.Tensor:
    return x.square().flatten(1).mean(1).sqrt()


def normalize(t: torch.Tensor) -> torch.Tensor:
    return t / rms(t).clamp_min(1e-12).view(-1, 1, 1, 1)


def project_rms(z: torch.Tensor, z0: torch.Tensor, rho) -> torch.Tensor:
    d = z - z0
    cur = rms(d).clamp_min(1e-12)
    lim = torch.as_tensor(rho, device=z.device, dtype=z.dtype)
    if lim.ndim == 0:
        lim = lim.expand_as(cur)
    return z0 + d * (lim / cur).clamp_max(1).view(-1, 1, 1, 1)


class SPDHead(nn.Module):
    """Predicts a per-position positive-definite operator from (c, z, t, g).

    P = diag(softplus(d) + eps) + U U^T, with U of shape (rank, 4) at each
    position. Output is initialised to the identity (d such that softplus gives
    ~1, U = 0), so a freshly built head reproduces the plain gradient step and
    training has to earn any deviation from it.
    """

    def __init__(self, rank: int = 2, in_ch: int = 4 + 4 + 4 + 5, width: int = 48,
                 eps: float = 1e-3):
        super().__init__()
        self.rank = rank
        self.eps = eps
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, width, 3, padding=1), nn.SiLU(),
            nn.Conv2d(width, width, 3, padding=1), nn.SiLU(),
            nn.Conv2d(width, 4 + rank * 4, 1),
        )
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, c, z, tid, g):
        b = z.shape[0]
        tmap = F.one_hot(tid.long(), 5).float().view(b, 5, 1, 1).expand(-1, -1, *z.shape[-2:])
        feat = torch.cat([c.float(), z.float(), normalize(g).float(), tmap], 1)
        out = self.net(feat)
        diag_raw, u_raw = out[:, :4], out[:, 4:]
        diag = F.softplus(diag_raw) + self.eps
        u = u_raw.view(b, self.rank, 4, *z.shape[-2:])
        return diag, u

    def apply(self, diag, u, g):
        """delta = P g, with P = diag(diag) + u u^T applied per position."""
        dg = diag * g
        # u: (B,r,4,H,W); g: (B,4,H,W) -> (u . g) then broadcast back
        ug = (u * g.unsqueeze(1)).sum(2)                  # (B,r,H,W)
        return dg + (u * ug.unsqueeze(2)).sum(1)


@dataclass
class UnrollConfig:
    steps: int = 2
    step_rms: float = 0.08
    rho: float = 0.25
    detach_gradient: bool = True     # first-order truncated unroll, not exact meta


class LatentSPDEditor(nn.Module):
    """B-z: SPD-modulated latent updates, K steps, all under one frozen R1."""

    def __init__(self, critic: nn.Module, head: SPDHead, cfg: UnrollConfig):
        super().__init__()
        self.critic = critic
        self.head = head
        self.cfg = cfg
        for p in self.critic.parameters():
            p.requires_grad_(False)

    def forward(self, z0, c, tid):
        z = z0.detach().clone()
        states = [z.clone()]
        trace = []
        for k in range(self.cfg.steps):
            zr = z.detach().clone().requires_grad_(True)
            # R1 must NOT be under no_grad: we need its input gradient.
            m = target_margin(self.critic, zr, tid)
            g = torch.autograd.grad(m.sum(), zr)[0].detach() if self.cfg.detach_gradient \
                else torch.autograd.grad(m.sum(), zr, create_graph=True)[0]
            diag, u = self.head(c, z, tid, g)
            delta = self.head.apply(diag, u, g)
            cand = z + self.cfg.step_rms * normalize(delta)
            cand = project_rms(cand, z0, self.cfg.rho)
            trace.append({"step": k, "margin_before": float(m.mean()),
                          "displacement_rms": float(rms(cand - z0).mean())})
            z = cand
            states.append(z.clone())
        return {"final": z, "states": torch.stack(states, 1), "trace": trace}


class ControlSPDEditor(nn.Module):
    """B-u: SPD updates in the generator's control coordinates (A3's u-space)."""

    def __init__(self, generator, critic, head_u, cfg: UnrollConfig):
        super().__init__()
        self.generator = generator     # ControlledGenerator
        self.critic = critic
        self.head = head_u
        self.cfg = cfg
        for p in self.critic.parameters():
            p.requires_grad_(False)

    def forward(self, c, z0, tid, u0):
        u = u0.detach().clone()
        states = []
        for k in range(self.cfg.steps):
            ur = u.detach().clone().requires_grad_(True)
            z = self.generator(c, 0.0, c, tid, controls=ur)
            m = target_margin(self.critic, z, tid)
            g_u = torch.autograd.grad(m.sum(), ur)[0].detach()
            scale = g_u.abs().mean().clamp_min(1e-8)
            diag = F.softplus(self.head["diag"](c, z, tid, g_u / scale)) + 1e-3
            u = u + self.cfg.step_rms * (diag * g_u)
            u = u.clamp(-self.cfg.rho, self.cfg.rho)
            states.append(u.clone())
        z = self.generator(c, 0.0, c, tid, controls=u)
        return {"final": z, "u": u, "states": torch.stack(states, 1)}
