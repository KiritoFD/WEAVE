"""Turn a V8 arm into a src.infer generator, then let src.eval measure it.

The runner never reimplements inference: it builds one of the registered
src.infer kinds with the arm's parameters. New arms therefore cost no new
inference code.
"""
from __future__ import annotations

from pathlib import Path
import json

import torch

from src.infer import InferSpec, build, load_c3unet, canonicalizer, load_critic

REPO = Path(__file__).resolve().parents[2]
B4 = REPO / "runs/v6/P1_B4_distill50/P1_B4_distill50.pt"
Q2A = REPO / "runs/v6/Q2a_embed_style/Q2a_embed_style.pt"
B3 = REPO / "runs/v6/P1_B3_distill20/P1_B3_distill20.pt"


def spec_for(arm: dict) -> InferSpec:
    """Map one arm dict to a src.infer spec (never a new inference path)."""
    kind = arm.get("kind")
    if kind in ("B3", "B4", "Q2aDirect"):
        ckpt = {"B3": B3, "B4": B4, "Q2aDirect": Q2A}[kind]
        return InferSpec(ckpt=ckpt, kind="direct", extra={"arm": arm["id"]})
    if kind == "Oracle":
        return InferSpec(ckpt=Q2A, kind="oracle",
                         extra={"oracle_steps": 1, "oracle_rms": 0.25, "arm": arm["id"]})
    if kind in ("R1Full", "R1TopK"):
        return InferSpec(ckpt=B4, kind="r1_steps", steps=4, step_rms=0.08,
                         extra={"topk_frac": 0.25 if kind == "R1TopK" else 0.0,
                                "arm": arm["id"]})
    if kind == "random":
        return InferSpec(ckpt=B4, kind="random", step_rms=arm.get("step_rms", 0.08),
                         extra={"seed": arm.get("seed", 0), "arm": arm["id"]})
    if kind == "probe" or arm.get("energy") == "M0":
        # H0 probes and legacy E3 are edits driven by an energy over the bank.
        return InferSpec(ckpt=B4, kind="energy", steps=arm.get("steps", 1),
                         step_rms=arm.get("step_rms", 0.08),
                         energy=arm.get("energy", "M0"),
                         extra={"arm": arm["id"], "direction": arm.get("direction", "")})
    if kind in ("Legacy4", "True4"):
        return InferSpec(ckpt=B4, kind="energy", steps=4, step_rms=0.08,
                         energy="M0", extra={"arm": arm["id"]})
    if arm.get("energy"):
        return InferSpec(ckpt=B4, kind="energy", steps=arm.get("steps", 4),
                         step_rms=arm.get("step_rms", 0.08),
                         energy=arm["energy"], rho=0.08 if arm.get("rho_tier") == "lo" else 0.16,
                         extra={"arm": arm["id"], "geometry": arm.get("geometry", "correct"),
                                "content": arm.get("content", "rms"),
                                "wrong_target": arm.get("wrong_target", False),
                                "weak_r1": arm.get("weak_r1", False)})
    raise KeyError(f"arm has no registered inference mapping: {arm.get('id')}")


def build_arm(arm: dict, device: str = "cuda"):
    return build(spec_for(arm), device)


if __name__ == "__main__":
    from exp.v8.arms import GROUPS
    ok, bad = 0, []
    for phase, arms in GROUPS.items():
        for arm in arms:
            try:
                spec_for(arm); ok += 1
            except KeyError as e:
                bad.append((arm.get("id"), str(e)))
    print(f"mapped {ok} arms; unmapped {len(bad)}")
    for b in bad[:10]:
        print("  ", b)
